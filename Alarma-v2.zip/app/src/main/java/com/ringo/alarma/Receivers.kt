package com.ringo.alarma

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", 0)
        val snooze = i.getBooleanExtra("snooze", false)
        if (id > 0 && !snooze) {
            val a = Store.find(c, id)
            if (a != null) {
                if (a.days == 0) {
                    a.enabled = false
                    Store.upsert(c, a)
                } else {
                    Scheduler.schedule(c, a)
                }
            }
        }
        if (id == TIMER_ID && !snooze) {
            Store.putLong(c, "timer_end", 0L)
        }
        val s = Intent(c, AlarmService::class.java)
        s.action = AlarmService.ACTION_START
        s.putExtra("id", id)
        c.startForegroundService(s)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.rescheduleAll(c)
        val end = Store.getLong(c, "timer_end")
        if (end > System.currentTimeMillis()) {
            Scheduler.scheduleTimer(c, end)
        } else {
            Store.putLong(c, "timer_end", 0L)
        }
    }
}
