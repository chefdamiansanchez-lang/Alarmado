package com.ringo.alarma

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RingActivity : Activity() {

    private val finisher = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )

        val id = intent.getIntExtra("id", 0)
        val label = intent.getStringExtra("label") ?: "Alarma"

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(C.BG)
        root.setPadding(dp(24), dp(24), dp(24), dp(24))

        val clock = tv(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), 80f, C.TEXT, true)
        clock.gravity = Gravity.CENTER
        root.addView(clock, LinearLayout.LayoutParams(MATCH, WRAP))

        val lab = tv(label, 26f, C.ACCENT, true)
        lab.gravity = Gravity.CENTER
        lab.setPadding(0, dp(8), 0, dp(56))
        root.addView(lab, LinearLayout.LayoutParams(MATCH, WRAP))

        val snooze = pill("Posponer 5 min", C.OFF, C.TEXT)
        val stop = pill("Detener", C.ACCENT, Color.BLACK)
        val lp1 = LinearLayout.LayoutParams(MATCH, WRAP)
        lp1.bottomMargin = dp(16)
        root.addView(snooze, lp1)
        root.addView(stop, LinearLayout.LayoutParams(MATCH, WRAP))

        snooze.setOnClickListener {
            val i = Intent(this, AlarmService::class.java)
            i.action = AlarmService.ACTION_SNOOZE
            i.putExtra("id", id)
            startService(i)
            finish()
        }
        stop.setOnClickListener {
            val i = Intent(this, AlarmService::class.java)
            i.action = AlarmService.ACTION_STOP
            startService(i)
            finish()
        }

        setContentView(root)

        val f = IntentFilter(AlarmService.FINISHED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(finisher, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(finisher, f)
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(finisher)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
