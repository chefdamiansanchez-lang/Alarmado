package com.ringo.alarma

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    private fun am(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun showIntent(c: Context): PendingIntent =
        PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun fireIntent(c: Context, id: Int, snooze: Boolean, requestCode: Int): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
        i.putExtra("id", id)
        i.putExtra("snooze", snooze)
        return PendingIntent.getBroadcast(
            c, requestCode, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun nextTrigger(a: Alarm, from: Long = System.currentTimeMillis()): Long {
        for (offset in 0..7) {
            val cal = Calendar.getInstance()
            cal.timeInMillis = from
            cal.add(Calendar.DAY_OF_YEAR, offset)
            cal.set(Calendar.HOUR_OF_DAY, a.hour)
            cal.set(Calendar.MINUTE, a.minute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val bit = cal.get(Calendar.DAY_OF_WEEK) - 1
            val dayOk = a.days == 0 || (((a.days shr bit) and 1) == 1)
            if (dayOk && cal.timeInMillis > from) return cal.timeInMillis
        }
        return from + 24L * 3600L * 1000L
    }

    private fun setClock(c: Context, at: Long, pi: PendingIntent) {
        try {
            am(c).setAlarmClock(AlarmManager.AlarmClockInfo(at, showIntent(c)), pi)
        } catch (e: Exception) {
        }
    }

    fun schedule(c: Context, a: Alarm) {
        if (a.enabled) {
            setClock(c, nextTrigger(a), fireIntent(c, a.id, false, a.id))
        } else {
            cancel(c, a)
        }
    }

    fun cancel(c: Context, a: Alarm) {
        am(c).cancel(fireIntent(c, a.id, false, a.id))
    }

    fun scheduleSnooze(c: Context, id: Int, minutes: Int) {
        val at = System.currentTimeMillis() + minutes * 60000L
        val code = if (id == TIMER_ID) 2999999 else 2000000 + id
        setClock(c, at, fireIntent(c, id, true, code))
    }

    fun scheduleTimer(c: Context, endAt: Long) {
        setClock(c, endAt, fireIntent(c, TIMER_ID, false, 3000000))
    }

    fun cancelTimer(c: Context) {
        am(c).cancel(fireIntent(c, TIMER_ID, false, 3000000))
    }

    fun rescheduleAll(c: Context) {
        for (a in Store.all(c)) schedule(c, a)
    }
}
