package com.ringo.alarma

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class AlarmService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START = "com.ringo.alarma.START"
        const val ACTION_STOP = "com.ringo.alarma.STOP"
        const val ACTION_SNOOZE = "com.ringo.alarma.SNOOZE"
        const val FINISHED = "com.ringo.alarma.FINISHED"
        const val CHANNEL = "ringo_ring"
        const val NOTIF_ID = 4242
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: SoundPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speech: String? = null
    private var wake: PowerManager.WakeLock? = null
    private var vibrator: Vibrator? = null
    private var running = false

    private val repeater = object : Runnable {
        override fun run() {
            if (running) {
                speakNow()
                handler.postDelayed(this, 45000)
            }
        }
    }

    private val autoStop = Runnable { stopAll() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent.action) {
            ACTION_START -> startRinging(intent.getIntExtra("id", 0))
            ACTION_SNOOZE -> {
                val id = intent.getIntExtra("id", 0)
                Scheduler.scheduleSnooze(this, id, 5)
                stopAll()
            }
            else -> stopAll()
        }
        return START_NOT_STICKY
    }

    private fun ensureChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Alarmas sonando", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(id: Int, label: String): Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val ring = Intent(this, RingActivity::class.java)
        ring.putExtra("id", id)
        ring.putExtra("label", label)
        ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val full = PendingIntent.getActivity(this, 1, ring, flags)

        val stopI = Intent(this, AlarmService::class.java)
        stopI.action = ACTION_STOP
        val stopPi = PendingIntent.getService(this, 2, stopI, flags)

        val snoozeI = Intent(this, AlarmService::class.java)
        snoozeI.action = ACTION_SNOOZE
        snoozeI.putExtra("id", id)
        val snoozePi = PendingIntent.getService(this, 3, snoozeI, flags)

        val timeText = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(label)
            .setContentText(timeText)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(full)
            .setFullScreenIntent(full, true)
            .addAction(0, "Posponer 5 min", snoozePi)
            .addAction(0, "Detener", stopPi)
            .build()
    }

    private fun startRinging(id: Int) {
        cleanup()
        running = true
        val alarm = if (id > 0) Store.find(this, id) else null
        val isTimer = id == TIMER_ID
        val label = when {
            isTimer -> "Temporizador"
            alarm != null && alarm.label.isNotEmpty() -> alarm.label
            else -> "Alarma"
        }

        ensureChannel()
        val notif = buildNotification(id, label)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ringo:alarm")
            w.acquire(10 * 60 * 1000L)
            wake = w
        } catch (e: Exception) {
        }

        val sp = SoundPlayer(this)
        sp.start(if (isTimer) 1 else (alarm?.sound ?: 0))
        player = sp

        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 500), 0))
            vibrator = v
        } catch (e: Exception) {
        }

        val wantSpeak = isTimer || (alarm?.speak ?: false)
        if (wantSpeak) {
            tts = TextToSpeech(this, this)
            if (isTimer) {
                speech = "El temporizador terminó."
            } else {
                val appCtx = applicationContext
                val alarmLabel = alarm?.label ?: ""
                Thread {
                    val w = Weather.fetch(appCtx)
                    handler.post {
                        if (running) {
                            speech = buildSpeech(alarmLabel, w)
                            speakNow()
                        }
                    }
                }.start()
            }
            handler.postDelayed(repeater, 45000)
        }
        handler.postDelayed(autoStop, 5 * 60 * 1000L)
    }

    private fun buildSpeech(label: String, weather: String?): String {
        val now = Calendar.getInstance()
        val h = now.get(Calendar.HOUR_OF_DAY)
        val m = now.get(Calendar.MINUTE)
        val day = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "AR")).format(now.time)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val period = when {
            h < 6 -> "de la madrugada"
            h < 12 -> "de la mañana"
            h < 20 -> "de la tarde"
            else -> "de la noche"
        }
        val verbo = if (h12 == 1) "Es la" else "Son las"
        val minTxt = if (m == 0) "en punto" else "y $m"
        val saludo = when {
            h < 12 -> "Buen día."
            h < 20 -> "Buenas tardes."
            else -> "Buenas noches."
        }
        val sb = StringBuilder()
        sb.append(saludo).append(" Hoy es ").append(day).append(". ")
        sb.append(verbo).append(" ").append(h12).append(" ").append(minTxt).append(" ").append(period).append(". ")
        if (weather != null) sb.append(weather).append(" ")
        if (label.isNotEmpty()) sb.append(label).append(".")
        return sb.toString()
    }

    private fun speakNow() {
        val t = speech ?: return
        if (!ttsReady) return
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "ringo")
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        var r = t.setLanguage(Locale("es", "AR"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = t.setLanguage(Locale("es"))
        }
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                player?.setVolume(0.2f)
            }

            override fun onDone(utteranceId: String?) {
                player?.setVolume(1f)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                player?.setVolume(1f)
            }
        })
        ttsReady = true
        if (speech != null) speakNow()
    }

    private fun cleanup() {
        running = false
        handler.removeCallbacksAndMessages(null)
        player?.stop()
        player = null
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
        }
        tts = null
        ttsReady = false
        speech = null
        try {
            vibrator?.cancel()
        } catch (e: Exception) {
        }
        vibrator = null
        try {
            val w = wake
            if (w != null && w.isHeld) w.release()
        } catch (e: Exception) {
        }
        wake = null
    }

    private fun stopAll() {
        cleanup()
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (e: Exception) {
        }
        val b = Intent(FINISHED)
        b.setPackage(packageName)
        sendBroadcast(b)
        stopSelf()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }
}
