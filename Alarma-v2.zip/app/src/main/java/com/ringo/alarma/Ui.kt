package com.ringo.alarma

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.TextView
import java.util.Locale

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
const val TIMER_ID = -1

val SOUNDS = arrayOf("Alarma del sistema", "Beep clásico", "Melodía", "Suave ascendente")

object C {
    val BG = Color.parseColor("#0F1020")
    val BAR = Color.parseColor("#171935")
    val CARD = Color.parseColor("#1D2040")
    val ACCENT = Color.parseColor("#FFB300")
    val TEXT = Color.parseColor("#F2F3FA")
    val MUTED = Color.parseColor("#9AA0C8")
    val OFF = Color.parseColor("#2B2F57")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun roundBg(color: Int, radiusPx: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radiusPx
    return g
}

fun Context.tv(text: String, sp: Float, color: Int = C.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = sp
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

fun Context.pill(text: String, bg: Int, fg: Int): TextView {
    val t = tv(text, 16f, fg, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(20), dp(14), dp(20), dp(14))
    t.background = roundBg(bg, dp(28).toFloat())
    return t
}

fun fmtStopwatch(ms: Long): String {
    val v = if (ms < 0) 0L else ms
    val cs = (v / 10) % 100
    val s = (v / 1000) % 60
    val m = (v / 60000) % 60
    val h = v / 3600000
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d.%02d", h, m, s, cs)
    else String.format(Locale.US, "%02d:%02d.%02d", m, s, cs)
}

fun fmtCountdown(sec: Long): String {
    val s = if (sec < 0) 0L else sec
    val h = s / 3600
    val m = (s % 3600) / 60
    val x = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, x)
    else String.format(Locale.US, "%02d:%02d", m, x)
}

fun untilText(ms: Long): String {
    val totalMin = (ms + 59999) / 60000
    val d = totalMin / 1440
    val h = (totalMin % 1440) / 60
    val m = totalMin % 60
    return when {
        d > 0 -> "Suena en $d d $h h $m min"
        h > 0 -> "Suena en $h h $m min"
        else -> "Suena en $m min"
    }
}
