package com.ringo.alarma

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.RingtoneManager

object Tones {
    const val RATE = 22050

    private fun note(freq: Double, ms: Int, vol: Double, fade: Int): ShortArray {
        val n = RATE * ms / 1000
        val f = maxOf(1, RATE * fade / 1000)
        val out = ShortArray(n)
        for (i in 0 until n) {
            var env = 1.0
            if (i < f) {
                env = i.toDouble() / f
            } else if (i > n - f) {
                env = (n - i).toDouble() / f
            }
            val v = Math.sin(2.0 * Math.PI * freq * i / RATE) * vol * env
            out[i] = (v * 32767.0).toInt().toShort()
        }
        return out
    }

    private fun gap(ms: Int): ShortArray = ShortArray(RATE * ms / 1000)

    private fun join(parts: List<ShortArray>): ShortArray {
        var total = 0
        for (p in parts) total += p.size
        val out = ShortArray(total)
        var pos = 0
        for (p in parts) {
            System.arraycopy(p, 0, out, pos, p.size)
            pos += p.size
        }
        return out
    }

    fun build(kind: Int): ShortArray {
        val parts = mutableListOf<ShortArray>()
        when (kind) {
            2 -> {
                val freqs = doubleArrayOf(523.25, 659.25, 783.99, 1046.5, 783.99, 659.25)
                for (f in freqs) parts.add(note(f, 260, 0.6, 15))
                parts.add(gap(900))
            }
            3 -> {
                val freqs = doubleArrayOf(392.0, 440.0, 493.88, 523.25, 587.33, 659.25)
                for (f in freqs) parts.add(note(f, 420, 0.45, 80))
                parts.add(gap(1200))
            }
            else -> {
                for (k in 0 until 3) {
                    parts.add(note(880.0, 160, 0.7, 8))
                    parts.add(gap(110))
                }
                parts.add(gap(800))
            }
        }
        return join(parts)
    }
}

class SoundPlayer(private val ctx: Context) {
    private var mp: MediaPlayer? = null
    private var track: AudioTrack? = null

    private fun attrs(): AudioAttributes =
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

    fun start(kind: Int) {
        stop()
        if (kind == 0) {
            var p: MediaPlayer? = null
            try {
                val uri = RingtoneManager.getActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                p = MediaPlayer()
                p.setAudioAttributes(attrs())
                p.setDataSource(ctx, uri)
                p.isLooping = true
                p.prepare()
                p.start()
                mp = p
                return
            } catch (e: Exception) {
                try {
                    p?.release()
                } catch (e2: Exception) {
                }
                mp = null
            }
        }
        try {
            val data = Tones.build(if (kind in 1..3) kind else 1)
            val t = AudioTrack.Builder()
                .setAudioAttributes(attrs())
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(Tones.RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(data.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(data, 0, data.size)
            t.setLoopPoints(0, data.size, -1)
            t.play()
            track = t
        } catch (e: Exception) {
        }
    }

    fun setVolume(v: Float) {
        try {
            mp?.setVolume(v, v)
        } catch (e: Exception) {
        }
        try {
            track?.setVolume(v)
        } catch (e: Exception) {
        }
    }

    fun stop() {
        try {
            mp?.stop()
        } catch (e: Exception) {
        }
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        mp = null
        try {
            track?.stop()
        } catch (e: Exception) {
        }
        try {
            track?.release()
        } catch (e: Exception) {
        }
        track = null
    }
}
