package com.ringo.alarma

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Alarm(
    val id: Int,
    var hour: Int,
    var minute: Int,
    var days: Int,
    var label: String,
    var sound: Int,
    var speak: Boolean,
    var enabled: Boolean
)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("ringo", Context.MODE_PRIVATE)

    fun getLong(c: Context, k: String, d: Long = 0L): Long = prefs(c).getLong(k, d)
    fun putLong(c: Context, k: String, v: Long) { prefs(c).edit().putLong(k, v).apply() }
    fun getBool(c: Context, k: String, d: Boolean = false): Boolean = prefs(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) { prefs(c).edit().putBoolean(k, v).apply() }
    fun getStr(c: Context, k: String, d: String = ""): String = prefs(c).getString(k, d) ?: d
    fun putStr(c: Context, k: String, v: String) { prefs(c).edit().putString(k, v).apply() }

    fun newId(): Int = (System.currentTimeMillis() % 1000000L).toInt() + 1

    fun all(c: Context): MutableList<Alarm> {
        val out = mutableListOf<Alarm>()
        try {
            val arr = JSONArray(getStr(c, "alarms", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Alarm(
                        o.getInt("id"), o.getInt("h"), o.getInt("m"), o.getInt("d"),
                        o.optString("l", ""), o.optInt("s", 0),
                        o.optBoolean("v", true), o.optBoolean("e", true)
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveAll(c: Context, list: List<Alarm>) {
        val arr = JSONArray()
        for (a in list) {
            val o = JSONObject()
            o.put("id", a.id)
            o.put("h", a.hour)
            o.put("m", a.minute)
            o.put("d", a.days)
            o.put("l", a.label)
            o.put("s", a.sound)
            o.put("v", a.speak)
            o.put("e", a.enabled)
            arr.put(o)
        }
        putStr(c, "alarms", arr.toString())
    }

    fun find(c: Context, id: Int): Alarm? = all(c).firstOrNull { it.id == id }

    fun upsert(c: Context, a: Alarm) {
        val l = all(c)
        val i = l.indexOfFirst { it.id == a.id }
        if (i >= 0) l[i] = a else l.add(a)
        saveAll(c, l)
    }

    fun delete(c: Context, id: Int) {
        saveAll(c, all(c).filter { it.id != id })
    }
}
