package com.ringo.alarma

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Weather {
    private fun describe(code: Int): String = when (code) {
        0 -> "despejado"
        1 -> "mayormente despejado"
        2 -> "parcialmente nublado"
        3 -> "nublado"
        45, 48 -> "con niebla"
        in 51..57 -> "con llovizna"
        in 61..67 -> "con lluvia"
        in 71..77 -> "con nieve"
        in 80..82 -> "con chubascos"
        in 95..99 -> "con tormenta"
        else -> "variable"
    }

    private fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun lastLocation(ctx: Context): Location? {
        if (!hasPermission(ctx)) return null
        var best: Location? = null
        try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            for (p in lm.getProviders(true)) {
                try {
                    val l = lm.getLastKnownLocation(p)
                    if (l != null && (best == null || l.time > best.time)) best = l
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
        return best
    }

    fun cacheLocation(ctx: Context) {
        val l = lastLocation(ctx) ?: return
        Store.putStr(ctx, "lat", l.latitude.toString())
        Store.putStr(ctx, "lon", l.longitude.toString())
    }

    fun fetch(ctx: Context): String? {
        try {
            val loc = lastLocation(ctx)
            var lat = Store.getStr(ctx, "lat")
            var lon = Store.getStr(ctx, "lon")
            if (loc != null) {
                lat = loc.latitude.toString()
                lon = loc.longitude.toString()
            }
            if (lat.isEmpty() || lon.isEmpty()) return null
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=" + lat +
                    "&longitude=" + lon + "&current=temperature_2m,weather_code&timezone=auto"
            )
            val con = url.openConnection() as HttpURLConnection
            con.connectTimeout = 5000
            con.readTimeout = 5000
            val text = con.inputStream.bufferedReader().use { it.readText() }
            val cur = JSONObject(text).getJSONObject("current")
            val t = Math.round(cur.getDouble("temperature_2m")).toInt()
            val code = cur.getInt("weather_code")
            return "El clima ahora: " + describe(code) + ", " + t + " grados."
        } catch (e: Exception) {
            return null
        }
    }
}
