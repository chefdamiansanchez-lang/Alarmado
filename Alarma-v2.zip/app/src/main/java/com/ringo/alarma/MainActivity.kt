package com.ringo.alarma

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var content: FrameLayout
    private val tabViews = ArrayList<TextView>()
    private var tab = 0
    private val handler = Handler(Looper.getMainLooper())
    private var tickRunnable: Runnable? = null
    private var alarmList: LinearLayout? = null
    private var previewPlayer: SoundPlayer? = null
    private val previewStop = Runnable { stopPreview() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BAR

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(C.BAR)
        val names = listOf("⏰ Alarmas", "⏱ Cronómetro", "⏳ Temporizador")
        for (i in names.indices) {
            val t = tv(names[i], 14f, C.MUTED, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(16), 0, dp(16))
            t.setOnClickListener { select(i) }
            tabViews.add(t)
            bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)

        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        Weather.cacheLocation(this)
        select(tab)
    }

    override fun onPause() {
        super.onPause()
        stopTick()
        stopPreview()
    }

    private fun askPermissions() {
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.ACCESS_COARSE_LOCATION)
            need.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Weather.cacheLocation(this)
    }

    private fun select(i: Int) {
        tab = i
        stopTick()
        for (k in tabViews.indices) {
            tabViews[k].setTextColor(if (k == i) C.ACCENT else C.MUTED)
        }
        content.removeAllViews()
        when (i) {
            0 -> showAlarms()
            1 -> showStopwatch()
            else -> showTimer()
        }
    }

    private fun startTick(block: () -> Unit) {
        stopTick()
        val r = object : Runnable {
            override fun run() {
                block()
                if (tickRunnable === this) handler.postDelayed(this, 50)
            }
        }
        tickRunnable = r
        handler.post(r)
    }

    private fun stopTick() {
        val r = tickRunnable
        if (r != null) handler.removeCallbacks(r)
        tickRunnable = null
    }

    // ---------------------------------------------------------------- ALARMAS

    private fun showAlarms() {
        val frame = FrameLayout(this)
        val scroll = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(16), dp(20), dp(16), dp(110))
        scroll.addView(list, ViewGroup.LayoutParams(MATCH, WRAP))
        frame.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        alarmList = list
        refreshAlarms()

        val fab = tv("+", 34f, Color.parseColor("#0F1020"), true)
        fab.gravity = Gravity.CENTER
        val oval = GradientDrawable()
        oval.shape = GradientDrawable.OVAL
        oval.setColor(C.ACCENT)
        fab.background = oval
        fab.setOnClickListener { editAlarm(null) }
        val lp = FrameLayout.LayoutParams(dp(64), dp(64), Gravity.BOTTOM or Gravity.END)
        lp.setMargins(0, 0, dp(20), dp(20))
        frame.addView(fab, lp)
        content.addView(frame, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun refreshAlarms() {
        val list = alarmList ?: return
        list.removeAllViews()
        val head = tv("Alarmas", 28f, C.TEXT, true)
        head.setPadding(dp(4), 0, 0, dp(12))
        list.addView(head)
        val alarms = Store.all(this).sortedWith(compareBy({ it.hour }, { it.minute }))
        if (alarms.isEmpty()) {
            val e = tv("No hay alarmas.\nToca + para crear una.", 16f, C.MUTED)
            e.setPadding(dp(4), dp(20), 0, 0)
            list.addView(e)
        }
        for (a in alarms) list.addView(alarmCard(a))
    }

    private fun daysText(mask: Int): String {
        if (mask == 0) return "Una vez"
        if (mask == 127) return "Todos los días"
        val order = intArrayOf(1, 2, 3, 4, 5, 6, 0)
        val names = arrayOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom")
        val parts = ArrayList<String>()
        for (i in 0..6) {
            if (((mask shr order[i]) and 1) == 1) parts.add(names[i])
        }
        return parts.joinToString(", ")
    }

    private fun alarmCard(a: Alarm): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(18), dp(14), dp(18), dp(14))
        row.background = roundBg(C.CARD, dp(20).toFloat())
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(12)
        row.layoutParams = lp

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        val time = tv(
            String.format(Locale.US, "%02d:%02d", a.hour, a.minute),
            40f, if (a.enabled) C.TEXT else C.MUTED, true
        )
        val sub = daysText(a.days) + (if (a.label.isNotEmpty()) " · " + a.label else "")
        left.addView(time)
        left.addView(tv(sub, 13f, C.MUTED))
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))

        val sw = Switch(this)
        sw.isChecked = a.enabled
        sw.setOnCheckedChangeListener { _, on ->
            a.enabled = on
            Store.upsert(this, a)
            time.setTextColor(if (on) C.TEXT else C.MUTED)
            if (on) {
                Scheduler.schedule(this, a)
                Toast.makeText(
                    this, untilText(Scheduler.nextTrigger(a) - System.currentTimeMillis()), Toast.LENGTH_SHORT
                ).show()
            } else {
                Scheduler.cancel(this, a)
            }
        }
        row.addView(sw)
        row.setOnClickListener { editAlarm(a) }
        return row
    }

    private fun picker(max: Int, v: Int): NumberPicker {
        val p = NumberPicker(this)
        p.minValue = 0
        p.maxValue = max
        p.displayedValues = Array(max + 1) { String.format(Locale.US, "%02d", it) }
        p.value = v
        p.descendantFocusability = NumberPicker.FOCUS_BLOCK_DESCENDANTS
        return p
    }

    private fun previewSound(kind: Int) {
        stopPreview()
        val p = SoundPlayer(this)
        p.start(kind)
        previewPlayer = p
        handler.postDelayed(previewStop, 4000)
    }

    private fun stopPreview() {
        handler.removeCallbacks(previewStop)
        previewPlayer?.stop()
        previewPlayer = null
    }

    private fun editAlarm(existing: Alarm?) {
        val now = Calendar.getInstance()
        val a = existing?.copy() ?: Alarm(
            Store.newId(), now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), 0, "", 0, true, true
        )
        var mask = a.days
        var sound = a.sound

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(8))

        val pickers = LinearLayout(this)
        pickers.orientation = LinearLayout.HORIZONTAL
        pickers.gravity = Gravity.CENTER
        val hp = picker(23, a.hour)
        val mp = picker(59, a.minute)
        pickers.addView(hp)
        pickers.addView(tv(" : ", 32f, C.TEXT, true))
        pickers.addView(mp)
        box.addView(pickers, LinearLayout.LayoutParams(MATCH, WRAP))

        val cap = tv("Repetir (sin días = una sola vez)", 12f, C.MUTED)
        cap.setPadding(0, dp(16), 0, dp(6))
        box.addView(cap)

        val order = intArrayOf(1, 2, 3, 4, 5, 6, 0)
        val letters = arrayOf("L", "M", "X", "J", "V", "S", "D")
        val dayViews = ArrayList<TextView>()
        val dayRow = LinearLayout(this)
        dayRow.orientation = LinearLayout.HORIZONTAL

        fun paintDays() {
            for (i in 0..6) {
                val on = (((mask shr order[i]) and 1) == 1)
                dayViews[i].background = roundBg(if (on) C.ACCENT else C.OFF, dp(20).toFloat())
                dayViews[i].setTextColor(if (on) Color.BLACK else C.TEXT)
            }
        }

        for (i in 0..6) {
            val d = tv(letters[i], 14f, C.TEXT, true)
            d.gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            d.setOnClickListener {
                mask = mask xor (1 shl order[i])
                paintDays()
            }
            dayViews.add(d)
            dayRow.addView(d, lp)
        }
        paintDays()
        box.addView(dayRow, LinearLayout.LayoutParams(MATCH, WRAP))

        val et = EditText(this)
        et.hint = "Etiqueta (opcional)"
        et.setText(a.label)
        et.setTextColor(C.TEXT)
        et.setHintTextColor(C.MUTED)
        et.setSingleLine(true)
        val etLp = LinearLayout.LayoutParams(MATCH, WRAP)
        etLp.topMargin = dp(12)
        box.addView(et, etLp)

        val soundBtn = tv("🔔 Sonido: " + SOUNDS[sound], 16f, C.ACCENT, true)
        soundBtn.setPadding(0, dp(16), 0, dp(8))
        soundBtn.setOnClickListener {
            var sel = sound
            val dlg = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Sonido")
                .setSingleChoiceItems(SOUNDS, sel) { _, which ->
                    sel = which
                    previewSound(which)
                }
                .setPositiveButton("Aceptar") { _, _ ->
                    sound = sel
                    soundBtn.text = "🔔 Sonido: " + SOUNDS[sound]
                }
                .setNegativeButton("Cancelar", null)
                .create()
            dlg.setOnDismissListener { stopPreview() }
            dlg.show()
        }
        box.addView(soundBtn)

        val cb = CheckBox(this)
        cb.text = "Anunciar día, hora y clima con voz"
        cb.setTextColor(C.TEXT)
        cb.isChecked = a.speak
        box.addView(cb)

        val scroll = ScrollView(this)
        scroll.addView(box)

        val b = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(if (existing == null) "Nueva alarma" else "Editar alarma")
            .setView(scroll)
            .setPositiveButton("Guardar") { _, _ ->
                hp.clearFocus()
                mp.clearFocus()
                a.hour = hp.value
                a.minute = mp.value
                a.days = mask
                a.label = et.text.toString().trim()
                a.sound = sound
                a.speak = cb.isChecked
                a.enabled = true
                Store.upsert(this, a)
                Scheduler.schedule(this, a)
                Toast.makeText(
                    this, untilText(Scheduler.nextTrigger(a) - System.currentTimeMillis()), Toast.LENGTH_SHORT
                ).show()
                refreshAlarms()
            }
            .setNegativeButton("Cancelar", null)
        if (existing != null) {
            b.setNeutralButton("Eliminar") { _, _ ->
                Scheduler.cancel(this, existing)
                Store.delete(this, existing.id)
                refreshAlarms()
            }
        }
        b.show()
    }

    // ------------------------------------------------------------ CRONÓMETRO

    private fun swElapsed(): Long {
        return if (Store.getBool(this, "sw_run")) {
            SystemClock.elapsedRealtime() - Store.getLong(this, "sw_base")
        } else {
            Store.getLong(this, "sw_acc")
        }
    }

    private fun lapsString(): String {
        val raw = Store.getStr(this, "sw_laps", "")
        if (raw.isEmpty()) return ""
        val totals = raw.split(",").mapNotNull { it.toLongOrNull() }
        val sb = StringBuilder()
        for (i in totals.indices.reversed()) {
            val prev = if (i > 0) totals[i - 1] else 0L
            sb.append(
                String.format(
                    Locale.US, "Vuelta %d   %s   %s\n",
                    i + 1, fmtStopwatch(totals[i] - prev), fmtStopwatch(totals[i])
                )
            )
        }
        return sb.toString()
    }

    private fun showStopwatch() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(20), dp(48), dp(20), dp(20))

        val big = tv("00:00.00", 54f, C.TEXT, true)
        big.typeface = Typeface.MONOSPACE
        big.gravity = Gravity.CENTER
        col.addView(big, LinearLayout.LayoutParams(MATCH, WRAP))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.setPadding(0, dp(32), 0, dp(24))
        val left = pill("Reiniciar", C.OFF, C.TEXT)
        val right = pill("Iniciar", C.ACCENT, Color.BLACK)
        val lpL = LinearLayout.LayoutParams(0, WRAP, 1f)
        lpL.setMargins(0, 0, dp(8), 0)
        val lpR = LinearLayout.LayoutParams(0, WRAP, 1f)
        lpR.setMargins(dp(8), 0, 0, 0)
        row.addView(left, lpL)
        row.addView(right, lpR)
        col.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))

        val lapsView = tv("", 16f, C.MUTED)
        lapsView.typeface = Typeface.MONOSPACE
        val sc = ScrollView(this)
        sc.addView(lapsView)
        col.addView(sc, LinearLayout.LayoutParams(MATCH, 0, 1f))
        content.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        fun render() {
            val running = Store.getBool(this, "sw_run")
            big.text = fmtStopwatch(swElapsed())
            right.text = if (running) "Pausar" else "Iniciar"
            left.text = if (running) "Vuelta" else "Reiniciar"
            lapsView.text = lapsString()
        }

        right.setOnClickListener {
            if (Store.getBool(this, "sw_run")) {
                Store.putLong(this, "sw_acc", SystemClock.elapsedRealtime() - Store.getLong(this, "sw_base"))
                Store.putBool(this, "sw_run", false)
            } else {
                Store.putLong(this, "sw_base", SystemClock.elapsedRealtime() - Store.getLong(this, "sw_acc"))
                Store.putBool(this, "sw_run", true)
            }
            render()
        }
        left.setOnClickListener {
            if (Store.getBool(this, "sw_run")) {
                val old = Store.getStr(this, "sw_laps", "")
                val t = swElapsed().toString()
                Store.putStr(this, "sw_laps", if (old.isEmpty()) t else "$old,$t")
            } else {
                Store.putLong(this, "sw_acc", 0L)
                Store.putStr(this, "sw_laps", "")
            }
            render()
        }

        render()
        startTick { big.text = fmtStopwatch(swElapsed()) }
    }

    // ------------------------------------------------------------ TEMPORIZADOR

    private fun showTimer() {
        val end = Store.getLong(this, "timer_end")
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(20), dp(48), dp(20), dp(20))

        if (end > System.currentTimeMillis()) {
            val big = tv("", 64f, C.TEXT, true)
            big.typeface = Typeface.MONOSPACE
            big.gravity = Gravity.CENTER
            col.addView(big, LinearLayout.LayoutParams(MATCH, WRAP))
            val cancel = pill("Cancelar", C.OFF, C.TEXT)
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(48)
            col.addView(cancel, lp)
            cancel.setOnClickListener {
                Store.putLong(this, "timer_end", 0L)
                Scheduler.cancelTimer(this)
                select(2)
            }
            content.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
            startTick {
                val rem = end - System.currentTimeMillis()
                if (rem <= 0) {
                    select(2)
                } else {
                    big.text = fmtCountdown((rem + 999) / 1000)
                }
            }
            return
        }

        val last = Store.getLong(this, "timer_last", 300L)
        val hp = picker(23, (last / 3600).toInt())
        val mp = picker(59, ((last % 3600) / 60).toInt())
        val sp = picker(59, (last % 60).toInt())

        val pickRow = LinearLayout(this)
        pickRow.orientation = LinearLayout.HORIZONTAL
        pickRow.gravity = Gravity.CENTER
        pickRow.addView(hp)
        pickRow.addView(tv(" h  ", 16f, C.MUTED))
        pickRow.addView(mp)
        pickRow.addView(tv(" min  ", 16f, C.MUTED))
        pickRow.addView(sp)
        pickRow.addView(tv(" s", 16f, C.MUTED))
        col.addView(pickRow, LinearLayout.LayoutParams(MATCH, WRAP))

        fun setPick(sec: Int) {
            hp.value = sec / 3600
            mp.value = (sec % 3600) / 60
            sp.value = sec % 60
        }

        val presets = LinearLayout(this)
        presets.orientation = LinearLayout.HORIZONTAL
        presets.gravity = Gravity.CENTER
        presets.setPadding(0, dp(24), 0, dp(24))
        val labels = arrayOf("1 min", "5 min", "10 min", "30 min")
        val secs = intArrayOf(60, 300, 600, 1800)
        for (i in 0..3) {
            val chip = tv(labels[i], 14f, C.TEXT, true)
            chip.setPadding(dp(14), dp(10), dp(14), dp(10))
            chip.background = roundBg(C.OFF, dp(20).toFloat())
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.setMargins(dp(4), 0, dp(4), 0)
            chip.setOnClickListener { setPick(secs[i]) }
            presets.addView(chip, lp)
        }
        col.addView(presets, LinearLayout.LayoutParams(MATCH, WRAP))

        val start = pill("Iniciar", C.ACCENT, Color.BLACK)
        col.addView(start, LinearLayout.LayoutParams(MATCH, WRAP))
        start.setOnClickListener {
            hp.clearFocus()
            mp.clearFocus()
            sp.clearFocus()
            val total = hp.value * 3600 + mp.value * 60 + sp.value
            if (total <= 0) {
                Toast.makeText(this, "Elige un tiempo", Toast.LENGTH_SHORT).show()
            } else {
                val endAt = System.currentTimeMillis() + total * 1000L
                Store.putLong(this, "timer_end", endAt)
                Store.putLong(this, "timer_last", total.toLong())
                Scheduler.scheduleTimer(this, endAt)
                select(2)
            }
        }
        content.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
    }
}
