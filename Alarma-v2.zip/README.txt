Alarma v2 - app Android (Kotlin, sin dependencias externas)
1. Sube este zip a un repositorio NUEVO de GitHub (o borra antes lo anterior).
2. Crea el archivo .github/workflows/build.yml con el contenido del yml.
3. En la pestana Actions espera el build; el APK queda en Releases (Alarma.apk).
